from .base import Media
from .static import StaticMedia

__all__ = [
    "Media",
    "StaticMedia",
]